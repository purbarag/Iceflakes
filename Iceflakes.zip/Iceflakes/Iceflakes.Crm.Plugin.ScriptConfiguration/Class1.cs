﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iceflakes.Crm.Plugin.ScriptConfiguration
{
    public class CreateRelationShipToScriptRun : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (Microsoft.Xrm.Sdk.IPluginExecutionContext) serviceProvider.GetService(typeof(Microsoft.Xrm.Sdk.IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory) serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            if(context.PrimaryEntityName.Equals("ice_scriptconfiguration", StringComparison.InvariantCultureIgnoreCase))
            {
                if(context.MessageName.Equals("create", StringComparison.InvariantCultureIgnoreCase))
                {
                    Entity target = context.InputParameters.ContainsKey("Target") ? context.InputParameters["Target"] as Entity : null;
                    if(target != null)
                    {
                        string configuredEntityLogicalName = target.Attributes.ContainsKey("ice_entitylogicalname") ? target.GetAttributeValue<string>("ice_entitylogicalname") : string.Empty;
                        if(!string.IsNullOrEmpty(configuredEntityLogicalName))
                        {
                            RetrieveEntityRequest request = new RetrieveEntityRequest()
                            {
                                EntityFilters = Microsoft.Xrm.Sdk.Metadata.EntityFilters.Entity,
                                LogicalName = configuredEntityLogicalName.ToLower(),
                                RetrieveAsIfPublished = true
                            };

                            RetrieveEntityResponse response = null;
                            try
                            {
                                response = (RetrieveEntityResponse) service.Execute(request);
                            }
                            catch(Exception)
                            {

                            }
                            if(response != null)
                            {
                                CreateOneToManyRelationship(service, response, "ice_scriptrun");
                                CreateOneToManyRelationship(service, response, "ice_scriptrunstep");
                                CreateOneToManyRelationship(service, response, "ice_scriptrunstepitem");
                            }
                        }
                    }
                }
            }
        }

        private bool CreateOneToManyRelationship(IOrganizationService service, RetrieveEntityResponse response, string toEntityLogicalName)
        {
            bool result = false;
            CreateOneToManyRequest relationshipRequest = new CreateOneToManyRequest()
            {
                //SolutionUniqueName = "default",
                OneToManyRelationship = new Microsoft.Xrm.Sdk.Metadata.OneToManyRelationshipMetadata()
                {
                    ReferencedEntity = response.EntityMetadata.LogicalName,
                    ReferencingEntity = toEntityLogicalName,
                    SchemaName = string.Join("", new string[] { "new_", response.EntityMetadata.LogicalName, "_", toEntityLogicalName }),
                    AssociatedMenuConfiguration = new Microsoft.Xrm.Sdk.Metadata.AssociatedMenuConfiguration()
                    {
                        Behavior = Microsoft.Xrm.Sdk.Metadata.AssociatedMenuBehavior.UseLabel,
                        Group = Microsoft.Xrm.Sdk.Metadata.AssociatedMenuGroup.Details,
                        Label = new Label("Script Runs", 1033),
                        Order = 10000
                    },

                    CascadeConfiguration = new Microsoft.Xrm.Sdk.Metadata.CascadeConfiguration()
                    {
                        Assign = Microsoft.Xrm.Sdk.Metadata.CascadeType.Cascade,
                        Delete = Microsoft.Xrm.Sdk.Metadata.CascadeType.Cascade,
                        Merge = Microsoft.Xrm.Sdk.Metadata.CascadeType.Cascade,
                        Reparent = Microsoft.Xrm.Sdk.Metadata.CascadeType.Cascade,
                        Share = Microsoft.Xrm.Sdk.Metadata.CascadeType.Cascade,
                        Unshare = Microsoft.Xrm.Sdk.Metadata.CascadeType.Cascade
                    }

                },
                Lookup = new Microsoft.Xrm.Sdk.Metadata.LookupAttributeMetadata()
                {
                    SchemaName = response.EntityMetadata.LogicalName.StartsWith("ice_") ? response.EntityMetadata.LogicalName.ToLower() + "id" : "ice_" + response.EntityMetadata.LogicalName + "id",
                    DisplayName = response.EntityMetadata.DisplayName != null && response.EntityMetadata.DisplayName.LocalizedLabels != null && response.EntityMetadata.DisplayName.LocalizedLabels.Count > 0 ? new Label(response.EntityMetadata.DisplayName.LocalizedLabels[0].Label, 1033) : null,
                    RequiredLevel = new Microsoft.Xrm.Sdk.Metadata.AttributeRequiredLevelManagedProperty(Microsoft.Xrm.Sdk.Metadata.AttributeRequiredLevel.None),
                    Description = new Label("Automatically created by Scripts configuration plugin", 1033)
                }
            };

            try
            {
                CreateOneToManyResponse relationshipResponse = (CreateOneToManyResponse) service.Execute(relationshipRequest);

                string parameterXml = @"<importexportxml>
                                                                <entities>
                                                                    {0}
                                                                </entities>
                                                            </importexportxml>";
                string entitylistXml = @"<entity>" + response.EntityMetadata.LogicalName.ToLower() + @"</entity>" + @"<entity>"+ toEntityLogicalName + "</entity>";
                parameterXml = string.Format(parameterXml, entitylistXml);
                PublishXmlRequest publishRequest = new PublishXmlRequest() { ParameterXml = parameterXml };
                PublishXmlResponse publishResponse = (PublishXmlResponse) service.Execute(publishRequest);

                result = true;
            }
            catch (Exception ex)
            {
                
            }

            return result;
        }
    }
}
