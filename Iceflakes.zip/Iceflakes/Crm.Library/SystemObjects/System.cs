﻿using Crm.Library.CrmMetadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crm.Library.SystemObjects
{
    public class User: CrmRecord
    {
        
    }
    public class BusinessUnit : CrmRecord
    {

    }

    public class Currency : CrmRecord
    {
        public string ISOCode { get; set; }
    }

    public class SystemSettings
    {

    }

    public class UserSettings
    {

    }

    public class CrmListDefinition
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Key { get; set; }


    }
    public class CrmListItem
    {

    }
}
