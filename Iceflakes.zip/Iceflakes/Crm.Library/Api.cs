﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Tooling.Connector;

namespace Crm.Library
{
    public class Api
    {
        private CrmServiceClient _service;
        public Api(CrmServiceClient client)
        {
            _service = client;
        }
    }
}
