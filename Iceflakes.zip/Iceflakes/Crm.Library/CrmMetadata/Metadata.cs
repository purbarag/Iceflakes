﻿using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crm.Library.CrmMetadata
{
    public class Metadata
    {
        private CrmServiceClient _service;
        private Metadata(CrmServiceClient client)
        {
            _service = client;
        }


    }
}
