﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crm.Library.CrmMetadata
{
    public class CrmRecord
    {
        public Guid Id { get; set; }
        
    }

    public class CrmEntity
    {
        public Guid Id { get; set; }

    }

    public class CrmAttribute
    {

    }

    public class CrmOptionSet
    {

    }

    public class CrmRelationship
    {

    }

    public class CrmForm
    {

    }

    public class CrmView
    {

    }

    public class CrmWebResource
    {
        public WebResourceType Type { get; set; }
        public string Name { get; set; }
    }

    public class CrmPluginAssembly : CrmRecord
    {
        public string LogicalName { get; set; }
    }

    public class CrmPlugin : CrmRecord
    {
        public string LogicalName { get; set; }
    }

    public class CrmPluginStep : CrmRecord
    {
        public string LogicalName { get; set; }
         
    }

    public class CrmSdkMessage : CrmRecord
    {
        public string LogicalName { get; set; }
        public string Name { get; set; }
    }

    public class CrmSdkMessageFilter : CrmRecord
    {
        public string LogicalName { get; set; }
        public CrmEntity _entity;
        public CrmSdkMessage _message;
    }

    public class CrmSecurityRole : CrmRecord
    {
        public List<CrmEntityRolePrivilegeMatrix> _matrix;
        public CrmSecurityRole()
        {
            _matrix = new List<CrmEntityRolePrivilegeMatrix>();
        }
        public void AddEntityRolePrivilege(CrmEntityRolePrivilegeMatrix rolePrivilege)
        {
            _matrix.Add(rolePrivilege);
        }
    }    

    public class CrmEntityRolePrivilegeMatrix
    {
        public CrmEntity _entity;
        public CrmRolePrivilege _privilege;
        public CrmEntity Entity { get { return _entity; } }

        public CrmEntityRolePrivilegeMatrix(CrmEntity entity, CrmRolePrivilege privilege)
        {
            _entity = entity;
            _privilege = privilege;
        }
    }

    public class CrmRolePrivilege
    {
        public PrivilegeType Type { get; set; }
        public PrivilegeRights Rights { get; set; }
        public CrmRolePrivilege(PrivilegeType type, PrivilegeRights rights)
        {
            this.Type = type;
            this.Rights = rights;
        }
    }

    public class Solution
    {

    }

    public class SolutionComponent
    {

    }



    #region Enumeration

    public enum PrivilegeType
    {
        Create,
        Read,
        Write,
        Delete,
        Append,
        AppendTo,
        Assign,
        Share
    }

    public enum PrivilegeRights
    {
        Organization,
        ParentChildBusinessUnit,
        BusinessUnit,
        User
    }

    public enum WebResourceType
    {

    }

    #endregion
}
