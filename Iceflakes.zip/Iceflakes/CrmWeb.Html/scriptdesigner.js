﻿selectedElement = null;
addedStepElement = null;


$(function() {
    $(".step-header").parent().next().find("div").hide();
    bindClick();    
});

function bindClick(){
    $(".step-header-content").click(function(event){        
        selectedElement = event.target;
        var $target = $(event.target);
        if(!$target.hasClass("step-selected")){
            //show/hide
            $(".step-header").parent().next().find("div").hide(); //hide all 
            $target.parent().parent().next().find(".step-content").slideToggle(); //unhide clicked header

            //hightlight
            $(".step-header-content").removeClass("step-selected");
            $target.addClass("step-selected");
        } 
    });
}
function unbindClick(){
    $(".step-header-content").unbind("click");
}

function addStep(){
    var stepCount = $(".step-header-content").length; 
    //alert(stepCount);
    var headerRow = "<tr><td style='width:100%; height:35px;' class='step-header'><div class='step-header-content newadded'><label class='stepheader'>"+ (stepCount +1).toString() +". Step Header </label></div></td></tr>";
    var stepContent = "<tr><td style='width:100%; background-color:#ffffff'><div class='step-content' style='width:100%; height:35px; border-radius:7px; border:1px solid #000000; background-color:#ffffff; margin-left:40px'>Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content. Some Content.</div></td></tr>";
    $("#steps").append(headerRow);
    addedStepElement = $(".newadded")[0];
    $("#steps").append(stepContent);

    bindClick();
    $(addedStepElement).parent().next().find("div").hide();
}

function moveElementUp() {
  var rowheader = $(selectedElement).parent().parent();
  var rowcontent = $(rowheader).next();
  var prevrowheader = $(rowheader).prev().prev();
  
  $(rowheader).insertBefore(prevrowheader);
  $(rowcontent).insertBefore(prevrowheader);
  
}

function moveElementDown(){
    var rowheader = $(selectedElement).parent().parent();
    var rowcontent = $(rowheader).next();
    var nextrowcontent = $(rowcontent).next().next();
    
    $(rowheader).insertAfter(nextrowcontent);
    $(rowcontent).insertAfter(rowheader);
}