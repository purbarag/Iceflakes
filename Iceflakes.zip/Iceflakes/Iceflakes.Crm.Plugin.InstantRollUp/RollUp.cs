﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iceflakes.Crm.Plugin.InstantRollUp
{
    public class RollUp : IPlugin
    {
        ITracingService tracing;
        private readonly List<string> _allowedMessages = new List<string>()
        {
            "create",
            "update",
            "delete",
            "setstate",
            "setstatedynamicentity"
        };
        private readonly List<int> _allowedStages = new List<int>()
        {
            40
        };
        public void Execute(IServiceProvider serviceProvider)
        {
            Microsoft.Xrm.Sdk.IPluginExecutionContext _context = (Microsoft.Xrm.Sdk.IPluginExecutionContext) serviceProvider.GetService(typeof(Microsoft.Xrm.Sdk.IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory) serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService _service = serviceFactory.CreateOrganizationService(_context.UserId);
            tracing = (ITracingService) serviceProvider.GetService(typeof(ITracingService));
            Entity _entity = null;
            Entity _preEntityImage = null;
            if (_context.InputParameters.Contains("Target") && _context.InputParameters["Target"] is Entity)
                _entity = _context.InputParameters["Target"] as Entity;
            if (_context.PreEntityImages.Contains("PreImage"))
                _preEntityImage = _context.PreEntityImages["PreImage"];


            if (_allowedMessages.Contains(_context.MessageName.ToLower())   //check message - create/update/delete/setstate/setstatedynamic
                && _allowedStages.Contains(_context.Stage))                    //check stage post async
            {
                try
                {
                    string logicalName = _entity.LogicalName.ToLower();

                    var rollupConfigs = GetRollUpConfigurations(_service, logicalName);
                    SdkMessage message = TranslateSdkMessage(_context.MessageName.ToLower());

                    //determine whether to fire rollup or not
                    var configuredAttributes = rollupConfigs.Select(x => x.ChildEntityAttributeLogicalName.ToLower()).ToList();
                    bool isRollUpFieldConfigured = false;
                    Entity childEntity = new Entity(logicalName);

                    switch (message)
                    {
                        case SdkMessage.Create:
                        case SdkMessage.Update:
                            _entity.Attributes.Keys.ToList().ForEach(x =>
                            {
                                if (configuredAttributes.Contains(x.ToLower()))
                                    isRollUpFieldConfigured = true;
                            });
                            List<string> parentLookupAttrs = rollupConfigs.Select(x => x.ParentLookupAttributeLogicalName).Distinct().ToList();
                            List<string> childRecordContextAttributes = _entity.Attributes.Keys.ToList().Except(parentLookupAttrs).ToList();
                            List<string> childRecordAttrs = new List<string>();
                            childRecordAttrs.AddRange(parentLookupAttrs);
                            childRecordAttrs.AddRange(childRecordContextAttributes);
                            childRecordAttrs.Add("statecode");
                            childEntity = _service.Retrieve(_entity.LogicalName, _entity.Id, new ColumnSet(childRecordAttrs.ToArray()));
                            break;
                        case SdkMessage.Delete:
                            childEntity = _preEntityImage;
                            break;
                        case SdkMessage.SetState:
                        case SdkMessage.SetStateDynamicEntity:
                            childEntity = _preEntityImage;
                            break;
                    }


                    if (isRollUpFieldConfigured)
                    {
                        Rollup(childEntity, message, _service, rollupConfigs);
                    }
                }
                catch (Exception ex)
                {
                    tracing.Trace("{0}", ex.StackTrace);
                    throw new InvalidPluginExecutionException(ex.Message);
                }
            }
        }

        private SdkMessage TranslateSdkMessage(string messageName)
        {
            switch (messageName.ToLower())
            {
                case "create":
                    return SdkMessage.Create;
                case "update":
                    return SdkMessage.Update;
                case "delete":
                    return SdkMessage.Delete;
                case "setstate":
                    return SdkMessage.SetState;
                case "setstatedynamicentity":
                    return SdkMessage.SetStateDynamicEntity;
            }

            return SdkMessage.None;
        }
        private List<RollUpConfiguration> GetRollUpConfigurations(IOrganizationService service, string childEntityLogicalName)
        {
            List<RollUpConfiguration> retValue = new List<RollUpConfiguration>();
            QueryExpression query = new QueryExpression("ice_instantrollupconfiguration");
            query.ColumnSet = new ColumnSet(true);
            query.Criteria.AddCondition(new ConditionExpression("ice_childentitylogicalname", ConditionOperator.Equal, childEntityLogicalName));
            query.Criteria.AddCondition(new ConditionExpression("statecode", ConditionOperator.Equal, 0));

            var result = service.RetrieveMultiple(query).Entities;

            retValue.AddRange(result.Select(x =>
            {
                return new RollUpConfiguration()
                {
                    RollupEntityLogicalName = x.Attributes.Contains("ice_rollupentitylogicalname") ? x.GetAttributeValue<string>("ice_rollupentitylogicalname") : string.Empty,
                    RollupAttributeLogicalName = x.Attributes.Contains("ice_rollupentityattributelogicalname") ? x.GetAttributeValue<string>("ice_rollupentityattributelogicalname") : string.Empty,
                    ChildEntityLogicalName = x.Attributes.Contains("ice_childentitylogicalname") ? x.GetAttributeValue<string>("ice_childentitylogicalname") : string.Empty,
                    ChildEntityAttributeLogicalName = x.Attributes.Contains("ice_childentityattributelogicalname") ? x.GetAttributeValue<string>("ice_childentityattributelogicalname") : string.Empty,
                    ParentLookupAttributeLogicalName = x.Attributes.Contains("ice_parententitylookupattributename") ? x.GetAttributeValue<string>("ice_parententitylookupattributename") : string.Empty,
                    RollupAttributeType = x.Attributes.Contains("ice_rollupattributetype") ? (RollupAttributeType) x.GetAttributeValue<OptionSetValue>("ice_rollupattributetype").Value : RollupAttributeType.None,
                    RollupOperator = x.Attributes.Contains("hsbc_iceupoperator") ? (RollupOperator) x.GetAttributeValue<OptionSetValue>("ice_rollupoperator").Value : RollupOperator.None,
                    IncludeInactiveRecords = x.Attributes.Contains("ice_includeinactiverecords") ? x.GetAttributeValue<bool>("ice_includeinactiverecords") : false
                };
            }));

            return retValue;
        }
        public bool Rollup(Entity childEntityRecord, SdkMessage _message, IOrganizationService _service, List<RollUpConfiguration> _rollupConfigurations)
        {
            bool retValue = false;

            //validate arguments
            if (childEntityRecord == null) return retValue;

            foreach (var rollupConfig in _rollupConfigurations)
            {
                EntityReference parentRecordRef = childEntityRecord.GetAttributeValue<EntityReference>(rollupConfig.ParentLookupAttributeLogicalName);
                if (parentRecordRef == null)
                    continue;

                //get all child record for parent record except currentrecord
                QueryExpression query = new QueryExpression(rollupConfig.ChildEntityLogicalName);
                query.ColumnSet = new ColumnSet(new string[] { rollupConfig.ChildEntityAttributeLogicalName });
                query.Criteria.AddCondition(new ConditionExpression(rollupConfig.ParentLookupAttributeLogicalName, ConditionOperator.Equal, parentRecordRef.Id));
                query.Criteria.AddCondition(new ConditionExpression(rollupConfig.ChildEntityLogicalName + "id", ConditionOperator.NotEqual, childEntityRecord.Id));
                if (!rollupConfig.IncludeInactiveRecords)
                    query.Criteria.AddCondition(new ConditionExpression("statecode", ConditionOperator.Equal, 0));
                var results = _service.RetrieveMultiple(query).Entities.ToList();


                bool booleanResult = false;
                string stringResult = string.Empty;
                int wholeNumberResult = 0;
                decimal decimalResult = 0.0M;
                float floatingpointResult = 0.0F;
                decimal currencyResult = 0.0M;

                object rollUpValue = null;

                bool existingBooleanValue = false;
                string existingStringValue = string.Empty;
                int existingWholeNumberValue = 0;
                decimal existingDecimalValue = 0.0M;
                float existingFloatingpointValue = 0.0F;
                decimal existingCurrencyValue = 0.0M;

                int currentRecordState = childEntityRecord.GetAttributeValue<OptionSetValue>("statecode").Value;
                //retrieve parent record with the rollup attribute value
                var parentEntityRecord = _service.Retrieve(rollupConfig.RollupEntityLogicalName, parentRecordRef.Id, new ColumnSet(new string[] { rollupConfig.RollupAttributeLogicalName }));
                bool isDirty = false;

                switch (rollupConfig.RollupAttributeType)
                {
                    #region Whole Number
                    case RollupAttributeType.WholeNumber:
                        int currentWholeNumberValue = childEntityRecord.GetAttributeValue<int>(rollupConfig.ChildEntityAttributeLogicalName);

                        switch (rollupConfig.RollupOperator)
                        {
                            case RollupOperator.Sum:
                                wholeNumberResult = results.Select(x =>
                                {
                                    if (x.Attributes.Contains(rollupConfig.ChildEntityAttributeLogicalName))
                                        return x.GetAttributeValue<int>(rollupConfig.ChildEntityAttributeLogicalName);
                                    else
                                        return 0;
                                }).Sum();


                                switch (_message)
                                {
                                    case SdkMessage.Create:
                                    case SdkMessage.Update:
                                        wholeNumberResult = wholeNumberResult + currentWholeNumberValue;
                                        break;
                                    case SdkMessage.SetState:
                                    case SdkMessage.SetStateDynamicEntity:
                                        if (currentRecordState == 1)
                                        {
                                            if (rollupConfig.IncludeInactiveRecords)
                                                wholeNumberResult = wholeNumberResult + currentWholeNumberValue;
                                        }
                                        else
                                        {
                                            wholeNumberResult = wholeNumberResult + currentWholeNumberValue;
                                        }
                                        break;
                                    case SdkMessage.Delete:
                                        break;
                                }

                                break;
                            case RollupOperator.Product:
                                wholeNumberResult = results.Select(x =>
                                {
                                    if (x.Attributes.Contains(rollupConfig.ChildEntityAttributeLogicalName))
                                        return x.GetAttributeValue<int>(rollupConfig.ChildEntityAttributeLogicalName);
                                    else
                                        return 1;
                                }).Product<int>();
                                switch (_message)
                                {
                                    case SdkMessage.Create:
                                    case SdkMessage.Update:
                                        wholeNumberResult = wholeNumberResult * currentWholeNumberValue;
                                        break;
                                    case SdkMessage.SetState:
                                    case SdkMessage.SetStateDynamicEntity:
                                        if (currentRecordState == 1)
                                        {
                                            if (rollupConfig.IncludeInactiveRecords)
                                                wholeNumberResult = wholeNumberResult * currentWholeNumberValue;
                                        }
                                        else
                                        {
                                            wholeNumberResult = wholeNumberResult * currentWholeNumberValue;
                                        }
                                        break;
                                    case SdkMessage.Delete:
                                        break;
                                }
                                break;
                        }
                        existingWholeNumberValue = parentEntityRecord.GetAttributeValue<int>(rollupConfig.RollupAttributeLogicalName);
                        if (wholeNumberResult != existingWholeNumberValue)
                        {
                            rollUpValue = wholeNumberResult;
                            isDirty = true;
                        }
                        break;

                    #endregion

                    #region FloatingPoint Number

                    case RollupAttributeType.FloatingPointNumber:
                        float currentFloatValue = childEntityRecord.GetAttributeValue<float>(rollupConfig.ChildEntityAttributeLogicalName);

                        switch (rollupConfig.RollupOperator)
                        {
                            case RollupOperator.Sum:
                                floatingpointResult = results.Select(x =>
                                {
                                    if (x.Attributes.Contains(rollupConfig.ChildEntityAttributeLogicalName))
                                        return x.GetAttributeValue<float>(rollupConfig.ChildEntityAttributeLogicalName);
                                    else
                                        return 0.0F;
                                }).Sum();
                                switch (_message)
                                {
                                    case SdkMessage.Create:
                                    case SdkMessage.Update:
                                        floatingpointResult = floatingpointResult + currentFloatValue;
                                        break;
                                    case SdkMessage.SetState:
                                    case SdkMessage.SetStateDynamicEntity:
                                        if (currentRecordState == 1)
                                        {
                                            if (rollupConfig.IncludeInactiveRecords)
                                                floatingpointResult = floatingpointResult + currentFloatValue;
                                        }
                                        else
                                        {
                                            floatingpointResult = floatingpointResult + currentFloatValue;
                                        }
                                        break;
                                    case SdkMessage.Delete:
                                        break;
                                }
                                break;
                            case RollupOperator.Product:
                                floatingpointResult = results.Select(x =>
                                {
                                    if (x.Attributes.Contains(rollupConfig.ChildEntityAttributeLogicalName))
                                        return x.GetAttributeValue<int>(rollupConfig.ChildEntityAttributeLogicalName);
                                    else
                                        return 1.0F;
                                }).Product<float>();
                                switch (_message)
                                {
                                    case SdkMessage.Create:
                                    case SdkMessage.Update:
                                        floatingpointResult = floatingpointResult * currentFloatValue;
                                        break;
                                    case SdkMessage.SetState:
                                    case SdkMessage.SetStateDynamicEntity:
                                        if (currentRecordState == 1)
                                        {
                                            if (rollupConfig.IncludeInactiveRecords)
                                                floatingpointResult = floatingpointResult * currentFloatValue;
                                        }
                                        else
                                        {
                                            floatingpointResult = floatingpointResult * currentFloatValue;
                                        }
                                        break;
                                    case SdkMessage.Delete:
                                        break;
                                }
                                break;
                        }
                        existingFloatingpointValue = parentEntityRecord.GetAttributeValue<float>(rollupConfig.RollupAttributeLogicalName);
                        if (floatingpointResult != existingFloatingpointValue)
                        {
                            rollUpValue = floatingpointResult;
                            isDirty = true;
                        }

                        break;

                    #endregion

                    #region Decimal Number

                    case RollupAttributeType.DecimalNumber:
                        decimal currentDecimalValue = childEntityRecord.GetAttributeValue<decimal>(rollupConfig.ChildEntityAttributeLogicalName);

                        switch (rollupConfig.RollupOperator)
                        {
                            case RollupOperator.Sum:
                                decimalResult = results.Select(x =>
                                {
                                    if (x.Attributes.Contains(rollupConfig.ChildEntityAttributeLogicalName))
                                        return x.GetAttributeValue<decimal>(rollupConfig.ChildEntityAttributeLogicalName);
                                    else
                                        return 0.0M;
                                }).Sum();
                                switch (_message)
                                {
                                    case SdkMessage.Create:
                                    case SdkMessage.Update:
                                        decimalResult = decimalResult + currentDecimalValue;
                                        break;
                                    case SdkMessage.SetState:
                                    case SdkMessage.SetStateDynamicEntity:
                                        if (currentRecordState == 1)
                                        {
                                            if (rollupConfig.IncludeInactiveRecords)
                                                decimalResult = decimalResult + currentDecimalValue;
                                        }
                                        else
                                        {
                                            decimalResult = decimalResult + currentDecimalValue;
                                        }
                                        break;
                                    case SdkMessage.Delete:
                                        break;
                                }
                                break;
                            case RollupOperator.Product:
                                decimalResult = results.Select(x =>
                                {
                                    if (x.Attributes.Contains(rollupConfig.ChildEntityAttributeLogicalName))
                                        return x.GetAttributeValue<decimal>(rollupConfig.ChildEntityAttributeLogicalName);
                                    else
                                        return 1.0M;
                                }).Product<decimal>();
                                switch (_message)
                                {
                                    case SdkMessage.Create:
                                    case SdkMessage.Update:
                                        decimalResult = decimalResult * currentDecimalValue;
                                        break;
                                    case SdkMessage.SetState:
                                    case SdkMessage.SetStateDynamicEntity:
                                        if (currentRecordState == 1)
                                        {
                                            if (rollupConfig.IncludeInactiveRecords)
                                                decimalResult = decimalResult * currentDecimalValue;
                                        }
                                        else
                                        {
                                            decimalResult = decimalResult * currentDecimalValue;
                                        }
                                        break;
                                    case SdkMessage.Delete:
                                        break;
                                }
                                break;
                        }
                        existingDecimalValue = parentEntityRecord.GetAttributeValue<decimal>(rollupConfig.RollupAttributeLogicalName);
                        if (decimalResult != existingDecimalValue)
                        {
                            rollUpValue = decimalResult;
                            isDirty = true;
                        }
                        break;

                    #endregion

                    #region Currency

                    case RollupAttributeType.Currency:
                        tracing.Trace("Rollup attribute type currency");
                        decimal currentMoneyValue = childEntityRecord.GetAttributeValue<Money>(rollupConfig.ChildEntityAttributeLogicalName).Value;
                        switch (rollupConfig.RollupOperator)
                        {
                            case RollupOperator.Sum:
                                tracing.Trace("Rollup operator SUM");
                                currencyResult = results.Select(x =>
                                {
                                    if (x.Attributes.Contains(rollupConfig.ChildEntityAttributeLogicalName))
                                        return x.GetAttributeValue<Money>(rollupConfig.ChildEntityAttributeLogicalName).Value;
                                    else
                                        return 0.0M;
                                }).Sum();
                                break;
                        }
                        switch (_message)
                        {
                            case SdkMessage.Create:
                            case SdkMessage.Update:
                                tracing.Trace("Message : create/update");
                                currencyResult = currencyResult + currentMoneyValue;
                                //tracing.Trace("currencyResult : " + currencyResult.ToString());
                                break;
                            case SdkMessage.SetState:
                            case SdkMessage.SetStateDynamicEntity:
                                if (currentRecordState == 1)
                                {
                                    if (rollupConfig.IncludeInactiveRecords)
                                        currencyResult = currencyResult + currentMoneyValue;
                                }
                                else
                                {
                                    currencyResult = currencyResult + currentMoneyValue;
                                }
                                break;
                            case SdkMessage.Delete:
                                break;
                        }
                        existingCurrencyValue = parentEntityRecord.Attributes.Contains(rollupConfig.RollupAttributeLogicalName) ? parentEntityRecord.GetAttributeValue<Money>(rollupConfig.RollupAttributeLogicalName).Value : 0.0M;
                        //tracing.Trace("Currency Result : " + currencyResult.ToString());
                        if (currencyResult != existingCurrencyValue)
                        {
                            rollUpValue = new Money(currencyResult);
                            isDirty = true;
                        }
                        break;

                    #endregion

                    #region Boolean

                    case RollupAttributeType.Boolean:
                        bool currentBooleanValue = childEntityRecord.GetAttributeValue<bool>(rollupConfig.ChildEntityAttributeLogicalName);

                        switch (rollupConfig.RollupOperator)
                        {
                            case RollupOperator.LogicalAND:
                                booleanResult = !results.Select(x =>
                                {
                                    if (x.Attributes.Contains(rollupConfig.ChildEntityAttributeLogicalName))
                                        return x.GetAttributeValue<bool>(rollupConfig.ChildEntityAttributeLogicalName);
                                    else
                                        return false;
                                }).Contains(false);
                                switch (_message)
                                {
                                    case SdkMessage.Create:
                                    case SdkMessage.Update:
                                        booleanResult = booleanResult && currentBooleanValue;
                                        break;
                                    case SdkMessage.SetState:
                                    case SdkMessage.SetStateDynamicEntity:
                                        if (currentRecordState == 1)
                                        {
                                            if (rollupConfig.IncludeInactiveRecords)
                                                booleanResult = booleanResult && currentBooleanValue;
                                        }
                                        else
                                        {
                                            booleanResult = booleanResult && currentBooleanValue;
                                        }
                                        break;
                                    case SdkMessage.Delete:
                                        break;
                                }
                                break;
                            case RollupOperator.LogicalOR:
                                booleanResult = results.Select(x =>
                                {
                                    if (x.Attributes.Contains(rollupConfig.ChildEntityAttributeLogicalName))
                                        return x.GetAttributeValue<bool>(rollupConfig.ChildEntityAttributeLogicalName);
                                    else
                                        return false;
                                }).Contains(true);
                                switch (_message)
                                {
                                    case SdkMessage.Create:
                                    case SdkMessage.Update:
                                        booleanResult = booleanResult || currentBooleanValue;
                                        break;
                                    case SdkMessage.SetState:
                                    case SdkMessage.SetStateDynamicEntity:
                                        if (currentRecordState == 1)
                                        {
                                            if (rollupConfig.IncludeInactiveRecords)
                                                booleanResult = booleanResult || currentBooleanValue;
                                        }
                                        else
                                        {
                                            booleanResult = booleanResult || currentBooleanValue;
                                        }
                                        break;
                                    case SdkMessage.Delete:
                                        break;
                                }
                                break;
                        }
                        existingBooleanValue = parentEntityRecord.GetAttributeValue<bool>(rollupConfig.RollupAttributeLogicalName);
                        if (booleanResult != existingBooleanValue)
                        {
                            rollUpValue = booleanResult;
                            isDirty = true;
                        }
                        break;
                    #endregion

                    #region Single Line of Text

                    case RollupAttributeType.SingleLineOfText:
                        string currentStringValue = childEntityRecord.GetAttributeValue<string>(rollupConfig.ChildEntityAttributeLogicalName);

                        switch (rollupConfig.RollupOperator)
                        {
                            case RollupOperator.Concatenate:
                                stringResult = string.Join("",
                                results.Select(x =>
                                {
                                    if (x.Attributes.Contains(rollupConfig.ChildEntityAttributeLogicalName))
                                        return x.GetAttributeValue<string>(rollupConfig.ChildEntityAttributeLogicalName);
                                    else
                                        return string.Empty;
                                }).ToArray());

                                switch (_message)
                                {
                                    case SdkMessage.Create:
                                    case SdkMessage.Update:
                                        stringResult = stringResult + currentStringValue;
                                        break;
                                    case SdkMessage.SetState:
                                    case SdkMessage.SetStateDynamicEntity:
                                        if (currentRecordState == 1)
                                        {
                                            if (rollupConfig.IncludeInactiveRecords)
                                                stringResult = stringResult + currentStringValue;
                                        }
                                        else
                                        {
                                            stringResult = stringResult + currentStringValue;
                                        }
                                        break;
                                    case SdkMessage.Delete:
                                        break;
                                }
                                break;
                        }
                        existingStringValue = parentEntityRecord.GetAttributeValue<string>(rollupConfig.RollupAttributeLogicalName);
                        if (stringResult != existingStringValue)
                        {
                            rollUpValue = stringResult;
                            isDirty = true;
                        }
                        break;

                        #endregion
                }

                if (isDirty)
                {
                    //tracing.Trace("setting entity record of type {0}, attribute {1} with value {2}", parentEntityRecord.LogicalName, rollupConfig.RollupAttributeLogicalName, ((Money) rollUpValue).Value.ToString());
                    Entity parent = new Entity(parentEntityRecord.LogicalName, parentEntityRecord.Id);
                    parent[rollupConfig.RollupAttributeLogicalName] = rollUpValue;
                    _service.Update(parent);
                }
                retValue = true;
            }
            return retValue;
        }
    }
    public enum RollupAttributeType
    {
        None = -1,
        WholeNumber = 500000000,
        FloatingPointNumber = 500000001,
        DecimalNumber = 500000002,
        Currency = 500000003,
        Boolean = 500000004,
        SingleLineOfText = 500000005
    }
    public enum RollupOperator
    {
        None = -1,
        Sum = 500000000,
        Product = 500000001,
        Concatenate = 500000002,
        LogicalAND = 500000003,
        LogicalOR = 500000004,
    }
    public enum SdkMessage
    {
        Create,
        Update,
        Delete,
        Retrieve,
        SetState,
        SetStateDynamicEntity,
        None
    }
    public class RollUpConfiguration
    {
        #region Private Fields

        private string _rollupEntityLogicalName;
        private string _rollupAttributeLogicalName;
        private string _childEntityLogicalName;
        private string _childEntityAttributeLogicalName;
        private string _parentLookupAttributeLogicalName;
        private RollupAttributeType _rollupAttributeType;
        private RollupOperator _rollupOperator;
        private bool _includeInactiveRecords;

        #endregion

        #region Public Properties

        public string RollupEntityLogicalName
        {
            get
            {
                return _rollupEntityLogicalName;
            }
            set
            {
                _rollupEntityLogicalName = value;
            }
        }
        public string RollupAttributeLogicalName
        {
            get
            {
                return _rollupAttributeLogicalName;
            }
            set
            {
                _rollupAttributeLogicalName = value;
            }
        }
        public string ChildEntityLogicalName
        {
            get
            {
                return _childEntityLogicalName;
            }
            set
            {
                _childEntityLogicalName = value;
            }
        }
        public string ChildEntityAttributeLogicalName
        {
            get
            {
                return _childEntityAttributeLogicalName;
            }
            set
            {
                _childEntityAttributeLogicalName = value;
            }

        }
        public string ParentLookupAttributeLogicalName
        {
            get
            {
                return _parentLookupAttributeLogicalName;
            }
            set
            {
                _parentLookupAttributeLogicalName = value;
            }
        }
        public RollupAttributeType RollupAttributeType
        {
            get
            {
                return _rollupAttributeType;
            }
            set
            {
                _rollupAttributeType = value;
            }
        }
        public RollupOperator RollupOperator
        {
            get
            {
                return _rollupOperator;
            }
            set
            {
                _rollupOperator = value;
            }
        }
        public bool IncludeInactiveRecords
        {
            get
            {
                return _includeInactiveRecords;
            }
            set
            {
                _includeInactiveRecords = value;
            }
        }

        #endregion
    }
    public static class InstantRollup_EXT
    {
        public static T Product<T>(this IEnumerable<T> values) where T : struct
        {
            int intProduct = 1;
            decimal decProduct = 1.0M;
            float flProduct = 1.0F;

            if (typeof(T) == typeof(int))
            {
                values.ToList().ForEach(x => { intProduct = intProduct * (int) Convert.ChangeType(x, typeof(int)); });
                return (T) Convert.ChangeType(intProduct, typeof(T));
            }
            if (typeof(T) == typeof(decimal))
            {
                values.ToList().ForEach(x => { decProduct = decProduct * (decimal) Convert.ChangeType(x, typeof(decimal)); });
                return (T) Convert.ChangeType(decProduct, typeof(T));
            }
            if (typeof(T) == typeof(int))
            {
                values.ToList().ForEach(x => { flProduct = flProduct * (float) Convert.ChangeType(x, typeof(float)); });
                return (T) Convert.ChangeType(flProduct, typeof(T));
            }

            return default(T);
        }


    }
}
