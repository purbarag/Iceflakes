﻿if(typeof CrmJS == "undefined"){
    CrmJS = { __namespace: true };
}