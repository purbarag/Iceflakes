﻿
if(typeof CrmJS == "undefined"){
    CrmJS = { __namespace: true };
}

CrmJS.DAL = {

    /** @description argument checks for functions.  
     * @param {string} argument argument name in string
     * @param {type} type name of argument.
     * @param {string} message message to prompt  
     */
    

    Create: function(record){

        var createdRecordId = null;

        try{
            var isEntityObjectValidated = CrmJS.DAL.validateEntityObject(record);
            if(isEntityObjectValidated==true){
                if (record.type.slice(-1) != "s") {
                    record.type = record.type + "s";
                }

                var object = CrmJS.DAL.transformSOAPToJSONObject(record);
                
                var req = new XMLHttpRequest();
                req.open("POST", encodeURI(CrmJS.DAL.getWebAPIPath() + record.type), false);
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");

                req.onreadystatechange = function () {
                    if (this.readyState == 4 /* complete */) {
                        req.onreadystatechange = null;
                        if (this.status == 204) {
                            var uri = this.getResponseHeader("OData-EntityId");
                            var regExp = /\(([^)]+)\)/;
                            var matches = regExp.exec(uri);
                            createdRecordId = matches[1];
                        }
                        else {
                            throw new CrmJS.Objects.JsError("Error during Create : " + this.statusText, "CrmJS.DAL.Create", CrmJS.Objects.Enum.ErrorType.Crud, "CrmJS.DAL.Create");
                        }
                    }
                };
                req.send(JSON.stringify(object));
                
                return createdRecordId;
            }
        } catch(e){
            throw new CrmJS.Objects.JsError(e.message, "CrmJS.DAL.Create", CrmJS.Objects.Enum.ErrorType.Crud, "CrmJS.DAL.Create");
        }
        
    },

    CreateAsync: function(record, successCallback, failureCallback){

        if(successCallback != null){
            CrmJS.Util._argumentCheckFunction(successCallback, 'function', 'successCallback argument is not valid');
        }
        if(failureCallback != null){
            CrmJS.Util._argumentCheckFunction(failureCallback, 'function', 'failureCallback argument is not valid');
        }
        
        try{
            var isEntityObjectValidated = CrmJS.DAL.validateEntityObject(record);
            if(isEntityObjectValidated==true){
                if (record.type.slice(-1) != "s") {
                    record.type = record.type + "s";
                }

                var object = CrmJS.DAL.transformSOAPToJSONObject(record);

                var req = new XMLHttpRequest();
                req.open("POST", encodeURI(CrmJS.DAL.getWebAPIPath() + type), false);
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");

                req.onreadystatechange = function () {
                    if (this.readyState == 4 /* complete */) {
                        req.onreadystatechange = null;
                        if (this.status == 204) {
                            var uri = this.getResponseHeader("OData-EntityId");
                            var regExp = /\(([^)]+)\)/;
                            var matches = regExp.exec(uri);
                            var createdRecordId = matches[1];
                            if(successCallback != null){
                                successCallback(createdRecordId);
                            }
                        }
                        else {
                            if(failureCallback != null){
                                throw new CrmJS.Objects.JsError("Error during CreateAsync : " + this.statusText, "CrmJS.DAL.CreateAsync", CrmJS.Objects.Enum.ErrorType.Crud, "CrmJS.DAL.CreateAsync");
                            }
                        }
                    }
                };
                req.send(JSON.stringify(object));
                
            }
        } catch(e){
            throw new CrmJS.Objects.JsError(e.message, "CrmJS.DAL.CreateAsync", CrmJS.Objects.Enum.ErrorType.Crud, "CrmJS.DAL.CreateAsync");
        }
    },

    Update: function(record){

        var result = false;
        try {
            var isEntityObjectValidated = CrmJS.DAL.validateEntityObject(record);
            if(isEntityObjectValidated==true){
                if (record.type.slice(-1) != "s") {
                    record.type = record.type + "s";
                }

                var req = new XMLHttpRequest();
                req.open("PATCH", encodeURI(this._WebAPIPath() + record.type + "(" + record.id + ")"), false);
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.onreadystatechange = function () {
                    if (this.readyState == 4 /* complete */) {
                        req.onreadystatechange = null;
                        if (this.status == 204 || this.status == 1223) {
                           result = true; 
                        }
                        else {
                            throw new CrmJS.Objects.JsError("Error during Update : " + this.statusText, "CrmJS.DAL.Update", CrmJS.Objects.Enum.ErrorType.Crud, "CrmJS.DAL.Update");                
                        }
                    }
                };
                req.send(JSON.stringify(object));

                return result;
            }
            
        } catch(e){
            throw new CrmJS.Objects.JsError(e.message, "CrmJS.DAL.Update", CrmJS.Objects.Enum.ErrorType.Crud, "CrmJS.DAL.Update");
        }
    },

    UpdateAsync: function(){

    },

    Delete: function (id, type) {
        
        
        CrmJS.Util._argumentCheck(id, 'string', "id argument not valid");
        var isvalidguid = CrmJS.Util.isValidGuid(id);
        if(isvalidguid == false){
            throw new CrmJS.Objects.JsError(message, "CrmJS.Util._argumentCheck", CrmJS.Objects.Enum.ErrorType.Syntax, "CrmJS.Util._argumentCheck");
        }
        CrmJS.Util._argumentCheck(type, 'string', "type argument not valid");
        
        if (type.slice(-1) != "s") {
            type = type + "s";
        }

        var result = false;
        try{

            var req = new XMLHttpRequest();
            req.open("DELETE", encodeURI(this._WebAPIPath() + type + "(" + id + ")", false));
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.onreadystatechange = function () {

                if (this.readyState == 4 /* complete */) {
                    req.onreadystatechange = null;
                    if (this.status == 204) {
                        result = true;
                    }
                    else {
                        result = false;
                    }
                }
            };
            req.send();

        } catch(e) {
            throw new CrmJS.Objects.JsError("An error occurred during CrmJS.DAL.Delete " + e.message, "CrmJS.DAL.Delete", CrmJS.Objects.Enum.ErrorType.Crud, "CrmJS.DAL.Delete");
        }
        
    },
   
    DeleteAsync: function (id, type, successCallback, failureCallback) {
        
        
        CrmJS.Util._argumentCheck(id, 'string', "id argument not valid");
        var isvalidguid = CrmJS.Util.isValidGuid(id);
        if(isvalidguid == false){
            throw new CrmJS.Objects.JsError(message, "CrmJS.Util._argumentCheck", CrmJS.Objects.Enum.ErrorType.Syntax, "CrmJS.Util._argumentCheck");
        }
        CrmJS.Util._argumentCheck(type, 'string', "type argument not valid");
        CrmJS.Util._argumentCheckFunction(successCallback, 'function', "argument not valid");
        CrmJS.Util._argumentCheckFunction(failureCallback, 'function', "argument not valid");

        if (type.slice(-1) != "s") {
            type = type + "s";
        }

        try{

            var req = new XMLHttpRequest();
            req.open("DELETE", encodeURI(this._WebAPIPath() + type + "(" + id + ")", true));
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.onreadystatechange = function () {

                if (this.readyState == 4 /* complete */) {
                    req.onreadystatechange = null;
                    if (this.status == 204) {
                        successCallback(result);
                    }
                    else {
                        failureCallback(this);
                    }
                }
            };
            req.send();

        } catch(e) {
            throw new CrmJS.Objects.JsError("An error occurred during CrmJS.DAL.DeleteAsync " + e.message, "CrmJS.DAL.DeleteAsync", CrmJS.Objects.Enum.ErrorType.Crud, "CrmJS.DAL.DeleteAsync");
        }
        
    },

    Fetch: function(fetchXml, calledFrom){

        CrmJS.Util._argumentCheck(fetchXml, 'string', "argument not valid");
        CrmJS.Util._argumentCheck(calledFrom, 'string', "argument not valid");
        
        var isValidFetchXml = CrmJS.Util.validateFetchXml(fetchXml);
        if(isValidFetchXml == false){
            throw new CrmJS.Objects.JsError("FetchXml is not valid", "CrmJS.DAL.Fetch", CrmJS.Objects.Enum.ErrorType.Syntax, "CrmJS.DAL.Fetch");
        }

        try {

            var xmlDoc = $.parseXML(fetchXml);
            var $xml = $(xmlDoc);
            var $entity = $xml.find("entity");
            var entityName = $entity.attr("name");

            var url = [Xrm.Page.context.getClientUrl(), "/api/data/v8.2/", entityName, "s?fetchXml=", encodeURIComponent(fetchXml)].join("");
            var results = null;

            var req = new XMLHttpRequest();
            req.open("GET", url, false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        results = JSON.parse(this.response);
                    } else {
                        Xrm.Utility.alertDialog(this.statusText);
                    }
                }
            };
            req.send();
            return CrmJS.DAL.transformJSONToSOAPResult(results, fetchXml);

        } catch(e){
            throw new CrmJS.Objects.JsError("An error occurred during CrmJS.DAL.Fetch " + e.message, "CrmJS.DAL.Fetch", CrmJS.Objects.Enum.ErrorType.Crud, "CrmJS.DAL.Fetch");
        }
        
    },

    FetchAsync: function(fetchxml, successCallback, failureCallback, calledFrom){
        
        CrmJS.Util._argumentCheck(fetchXml, 'string', "argument not valid");
        CrmJS.Util._argumentCheckFunction(successCallback, 'function', "argument not valid");
        CrmJS.Util._argumentCheckFunction(failureCallback, 'function', "argument not valid");
        CrmJS.Util._argumentCheck(calledFrom, 'string', "argument not valid");

        var isValidFetchXml = CrmJS.Util.validateFetchXml(fetchXml);
        if(isValidFetchXml == false){
            throw new CrmJS.Objects.JsError("FetchXml is not valid", "CrmJS.DAL.Fetch", CrmJS.Objects.Enum.ErrorType.Syntax, "CrmJS.DAL.Fetch");
        }

        try {

            var xmlDoc = $.parseXML(fetchXml);
            var $xml = $(xmlDoc);
            var $entity = $xml.find("entity");
            var entityName = $entity.attr("name");

            var url = [parent.Xrm.Page.context.getClientUrl(), "/api/data/v8.2/", entityName, "s?fetchXml=", encodeURIComponent(fetchXml)].join("");
            var results = null;

            var req = new XMLHttpRequest();
            req.open("GET", url, true);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        results = JSON.parse(this.response);
                        var formattedResult = CrmJS.DAL.transformJSONToSOAPResult(results, fetchXml);
                        if(successCallback){
                            successCallback(formattedResult);
                        }            
                    } else {
                        if(failureCallback){
                            failureCallback(this);
                        }
                    }
                }
            };
            req.send();

        } catch(e){
            throw new CrmJS.Objects.JsError("An error occurred during CrmJS.DAL.Fetch " + e.message, "CrmJS.DAL.Fetch", CrmJS.Objects.Enum.ErrorType.Crud, "CrmJS.DAL.Fetch");
        }
    },

    Associate: function(){

    },

    AssociateAsync: function(){

    },

    Disassociate: function(){

    },

    DisassociateAsync: function(){

    },

    LogError: function(e){

    },

    transformJSONToSOAPResult: function (jsonResult, fetchXml) {
        debugger;

        var retValue = new Array();

        if (jsonResult == null)
            return null;

        //get unique attributes from fetchxml
        var attributesFetch = new Array();
        var xmlDoc = $.parseXML(fetchXml);
        var $xml = $(xmlDoc);
        var $entity = $xml.find("entity");
        var $attributes = $entity.find("attribute");
        $attributes.each(function () {
            var attributeFetch = "";
            if ($(this).parent().prop("tagName").toLowerCase() == "link-entity") {
                var alias = $(this).parent().attr("alias");
                attributeFetch = [alias, ".", $(this).attr("name")].join("");
            } else {
                attrib = $(this).attr("name");
            }
            attributesFetch.push(attrib);
        });


        $(jsonResult.value).each(function () {
            var retObj = { attributes: {} };
            var jsonResultItem = this;
            var jsonKeys = Object.keys(jsonResultItem);
            var resultAttributes = new Array();
            for (var i = 0; i < attributesFetch.length; i++) {

                var key = attributesFetch[i];
                retObj.attributes[key] = { value: null, formattedValue: null, logicalname: null, attributename: null };
                if (key.indexOf(".") > 0) {
                    //aliased attribute
                    var keyParts = key.split(".");
                    var entityAliasName = keyParts[0];
                    var entityAttributeName = keyParts[1];

                    var valueKey = [entityAliasName, "_x002e_", entityAttributeName].join("");
                    retObj.attributes[key].value = jsonResultItem[valueKey];
                    var formattedValueKey = [entityAliasName, "_x002e_", entityAttributeName, "@OData.Community.Display.V1.FormattedValue"].join("");
                    retObj.attributes[key].formattedValue = jsonResultItem[formattedValueKey];

                } else {
                    //main entity attribute
                    var entityAttributeName = key;

                    //check if lookup then change attributename
                    if (CrmJS.DAL.isLookupAttribute(jsonKeys, entityAttributeName)) {
                        entityAttributeName = "_" + entityAttributeName + "_value";
                    }

                    var valueKey = entityAttributeName;
                    retObj.attributes[key].value = jsonResultItem[valueKey];
                    var formattedValueKey = [entityAttributeName, "@OData.Community.Display.V1.FormattedValue"].join("");
                    retObj.attributes[key].formattedValue = jsonResultItem[formattedValueKey];
                    var attributeNameKey = [entityAttributeName, "@Microsoft.Dynamics.CRM.associatednavigationproperty"].join("");
                    retObj.attributes[key].attributename = jsonResultItem[attributeNameKey];
                    var logicalNameKey = [entityAttributeName, "@Microsoft.Dynamics.CRM.lookuplogicalname"].join("");
                    retObj.attributes[key].logicalname = jsonResultItem[logicalNameKey];

                }

            }

            retValue.push(retObj);
        });

        return retValue;
    },

    transformSOAPToJSONObject: function(record){
        
        var object = {};
        $(Object.keys(record.attributes)).each(function(){
            object[this] = record.attributes[this];
        });
        return object;
    },

    isLookupAttribute: function (keys, value) {
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            if (key.indexOf(value) >= 0) {
                if (key[0] == "_") {
                    if (key.indexOf("_value@") >= 0) {
                        return true;
                    }
                }
            }
        }

        return false;
    },

    validateEntityObject: function(entity, message){
        
        if(entity.type == 'undefined' || entity.type == null){
            throw new CrmJS.Objects.JsError("Entity object type property is not valid", "CrmJS.DAL.validateEntityObject", CrmJS.Objects.Enum.ErrorType.Syntax, "CrmJS.DAL.validateEntityObject");
        }
        if(entity.attributes == 'undefined' || entity.attributes==null || typeof entity.attributes != 'Array' || entity.attributes.length == 0){
            throw new CrmJS.Objects.JsError("Entity object attributes property is not valid", "CrmJS.DAL.validateEntityObject", CrmJS.Objects.Enum.ErrorType.Syntax, "CrmJS.DAL.validateEntityObject");
        }
        if(message.toLowerCase() == 'update' && (entity.id=='undefined' || entity.id==null)){
            throw new CrmJS.Objects.JsError("Entity object id property is not valid", "CrmJS.DAL.validateEntityObject", CrmJS.Objects.Enum.ErrorType.Syntax, "CrmJS.DAL.validateEntityObject");
        }
        var isIdValidated = CrmJS.Util.isValidGuid(entity.id);
        if(isIdValidated==false){
            throw new CrmJS.Objects.JsError("Entity object id property is not of type GUID", "CrmJS.DAL.validateEntityObject", CrmJS.Objects.Enum.ErrorType.Syntax, "CrmJS.DAL.validateEntityObject");
        }

        return true;
    },

    getLookUp: function(attributeLogicalName, referencedEntityLogicalName, id){
        return { 
                key:attributeLogicalName.toLowerCase() + "@odata.bind", 
                value: ["/", referencedEntityLogicalName.toLowerCase() + "s(", id, ")"].join("") 
            };
    },

    getContext: function () {
        
        if (typeof GetGlobalContext != "undefined") { 
            return GetGlobalContext(); 
        } else {
            if (typeof Xrm != "undefined") {
                return Xrm.Page.context;
            }
            else { 
                throw new Error("Context is not available."); 
            }
        }
    },

    getClientUrl: function () {
        var clientUrl = CrmJS.DAL.getContext().getClientUrl()

        return clientUrl;
    },

    getWebAPIPath: function () {
        return CrmJS.DAL.getClientUrl() + "/api/data/v8.2/";
    },

    __namespace:true
};