﻿
if(typeof CrmJS == "undefined"){
    CrmJS = { __namespace: true };
}

CrmJS.Objects = {

    JsError: function(message, action, type, prevCallStack){
        this.message = message;
        this.action = action;
        this.type= type;
        this.prevCallStack = prevCallStack;
    },

    Entity: function(recordType,recordId){
        
        var entity = { 
            id: recordId, 
            type: recordType, 
            attributes: [],
            addAttribute: function(type, key, value){
                this.attributes.push(new Attribute(type, key, value));
            }
        };        
        
        return entity;

    },

    Attribute: function(attributeType, attributeKey, attributeValue){

        var attribute = { type: attributeType, key: attributeKey, value: attributeValue}
        return attribute;

    },

    __namespace:true
};

if(typeof CrmJS.Objects.Enum == "undefined"){
    CrmJS.Objects.Enum = { __namespace:true };
}

CrmJS.Objects.Enum.ErrorType = {
    Syntax: 100001,
    Crud: 100002,


    __namespace:true
};
